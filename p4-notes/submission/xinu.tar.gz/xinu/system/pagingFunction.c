/*
 * pagingFunction.c
 *
 *  Created on: 13-Nov-2020
 *      Author: prati
 */

#include <xinu.h>

uint32 allocateTable ( )
{
#ifdef DEBUG
    //sync_printf("allocateTable\n");
#endif
    pd_t* pageDirecBaseAddr = (pd_t*) (PDBASEADDR);
    uint32 i;
    for (i = 1; i < MAX_PT_SIZE; i++)
    {
        pd_t *pageTableEntry;
        if (pageDirecBaseAddr[i * ENTRIES].pd_alloc == 0)
        {
            for (pageTableEntry = &(pageDirecBaseAddr[i * ENTRIES]);
                    pageTableEntry < (pd_t*) ((XINU_PAGES + i + 1) * PAGE_SIZE);
                    pageTableEntry++)
            {
                pageTableEntry->pd_alloc = 1;
            }
            return (uint32) &(pageDirecBaseAddr[i * ENTRIES]);
        }
    }
    return 0;
}

syscall initializeUserPageDirectory ( uint32* pageDirectory )
{
    uint32 i;
    //allocateTable() return a free page address
    uint32 pd_ptr = allocateTable();

#ifdef DEBUG
    sync_printf("initializeUserPageDirectory\n");
#endif
    if (pd_ptr == 0)
    {
        return SYSERR;
    }
    pd_t *pd = (pd_t*) (pd_ptr);
    for (i = 0; i < MAX_PT_SIZE; i++)
    {
        pd[i].pd_pres = 0;
        pd[i].pd_write = 0;
        pd[i].pd_user = 0;
        pd[i].pd_pwt = 0;
        pd[i].pd_pcd = 0;
        pd[i].pd_acc = 0;
        pd[i].pd_mbz = 0;
        pd[i].pd_fmb = 0;
        pd[i].pd_global = 0;
        pd[i].pd_valid = 0;
        pd[i].pd_alloc = 0;
        pd[i].pd_base = 0;
    }
    pd_t* pageDirecBaseAddr = (pd_t*) proctab[0].prPDBR;
    uint32 k = 0;
    for (i = 0; i < 8; i++)
    {
        pd[i].pd_base = pageDirecBaseAddr[i].pd_base;
        pd[i].pd_pres = pageDirecBaseAddr[i].pd_pres;
        pd[i].pd_valid = pageDirecBaseAddr[i].pd_valid;
        pd[i].pd_alloc = pageDirecBaseAddr[i].pd_alloc;
//        if (pd[k].pd_base == 0)
//        {
//            uint32 pageDirEntry = allocateTable();
//            if (pageDirEntry != SYSERR)
//            {
//                pd[k].pd_base = pageDirEntry >> 12;
//                pd[k].pd_pres = 1;
//                pd[k].pd_valid = 1;
//                pd[k].pd_alloc = 1;
//            }
//            uint32 j;
//            //initialize table for the entry
//            for (j = 0; j < MAX_PT_SIZE; j++)
//            {
//                pt_t *curr_ptb = (pt_t*) (pd[k].pd_base << 12);
//                curr_ptb[j].pt_base = i;
//                curr_ptb[j].pt_pres = 1;
//                curr_ptb[j].pt_valid = 1;
//                curr_ptb[j].pt_write = 1;
//                curr_ptb[k].pt_alloc = 1;
//                i++;
//            }
//        }
//        k++;
    }

    *pageDirectory = (uint32) pd;
#ifdef DEBUG
    sync_printf("initializeUserPageDirectory i :: %d k :: %d\n", i, k - 1);
    sync_printf("initializeUserPageDirectory return :: %x\n", *pageDirectory);
#endif
    return OK;
}

void initPageDirectory ( )
{
    uint32 i;
    pd_t* pageDir = (pd_t*) (PDBASEADDR);
    for (i = 0; i < MAX_PT_SIZE; i++)
    {
        pageDir[i].pd_pres = 0;
        pageDir[i].pd_write = 0;
        pageDir[i].pd_user = 0;
        pageDir[i].pd_pwt = 0;
        pageDir[i].pd_pcd = 0;
        pageDir[i].pd_acc = 0;
        pageDir[i].pd_mbz = 0;
        pageDir[i].pd_fmb = 0;
        pageDir[i].pd_global = 0;
        pageDir[i].pd_valid = 0;
        pageDir[i].pd_alloc = 0;
        pageDir[i].pd_base = 0;
    }
    sync_printf("final value of i == %d\n", i);

    uint32 k = 0;
    for (i = 0; i < (XINU_PAGES);)
    {
        //initialize page directory entries
        if (pageDir[k].pd_base == 0)
        {
            uint32 pageDirEntry = allocateTable();
            if (pageDirEntry != SYSERR)
            {
                pageDir[k].pd_base = pageDirEntry >> 12;
                pageDir[k].pd_pres = 1;
                pageDir[k].pd_valid = 1;
                pageDir[i].pd_alloc = 1;
            }
            uint32 j;
            //initialize table for the entry
            for (j = 0; j < MAX_PT_SIZE; j++)
            {
                pt_t *curr_ptb = (pt_t*) (pageDir[k].pd_base << 12);
                curr_ptb[j].pt_base = i;
                curr_ptb[j].pt_pres = 1;
                curr_ptb[j].pt_valid = 1;
                curr_ptb[j].pt_write = 1;
                curr_ptb[j].pt_alloc = 1;
                i++;
            }
        }
        k++;
    }
    sync_printf("final value of i == %d\n", i);
    for (i = (XINU_PAGES); i < (XINU_PAGES + MAX_PT_SIZE);)
    {
        if (pageDir[k].pd_base == 0)
        {
            uint32 pageDirEntry = allocateTable();
            if (pageDirEntry != SYSERR)
            {
                pageDir[k].pd_base = pageDirEntry >> 12;
                pageDir[k].pd_pres = 1;
                pageDir[k].pd_valid = 1;
                pageDir[i].pd_alloc = 1;
            }
            uint32 j;
            //initialize table for the entry
            for (j = 0; j < MAX_PT_SIZE; j++)
            {
                pt_t *curr_ptb = (pt_t*) (pageDir[k].pd_base << 12);
                curr_ptb[j].pt_base = i;
                curr_ptb[j].pt_pres = 1;
                curr_ptb[j].pt_valid = 1;
                curr_ptb[j].pt_write = 1;
                curr_ptb[j].pt_alloc = 1;
                i++;
            }
        }
        k++;
    }
    sync_printf("final value of i == %d\n", i);
    for (i = (XINU_PAGES + MAX_PT_SIZE);
            i < (XINU_PAGES + MAX_PT_SIZE + MAX_FFS_SIZE);)
    {
        if (pageDir[k].pd_base == 0)
        {
            uint32 pageDirEntry = allocateTable();
            if (pageDirEntry != SYSERR)
            {
                pageDir[k].pd_base = pageDirEntry >> 12;
                pageDir[k].pd_pres = 1;
                pageDir[k].pd_valid = 1;
                pageDir[i].pd_alloc = 1;

            }
            uint32 j;
            //initialize table for the entry
            for (j = 0; j < MAX_PT_SIZE; j++)
            {
                pt_t *curr_ptb = (pt_t*) (pageDir[k].pd_base << 12);
                curr_ptb[j].pt_base = i;
                curr_ptb[j].pt_pres = 1;
                curr_ptb[j].pt_valid = 1;
                curr_ptb[j].pt_write = 1;
                curr_ptb[j].pt_alloc = 1;
                i++;
            }
        }
        k++;
    }
#ifdef DEBUG
    kprintf("pdbr: %x\n", pageDir);
#endif
    uint32 pdbr = ((uint32) pageDir) & 0xFFFFF000;
#ifdef DEBUG
    kprintf("pdbr: %x\n", pdbr);
#endif
    write_cr3(pdbr);
}

