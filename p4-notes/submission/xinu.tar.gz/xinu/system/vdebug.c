/*
 * vdebug.c
 *
 *  Created on: 13-Nov-2020
 *      Author: prati
 */
#include <xinu.h>

void sync_printf ( char *fmt, ... )
{
    intmask mask = disable();
    void *arg = __builtin_apply_args();
    __builtin_apply((void*) kprintf, arg, 100);
    restore(mask);
}

uint32 free_ffs_pages ( )
{
    return ffslist.mlength / PAGE_SIZE;
}

uint32 used_ffs_frames ( pid32 pid )
{
    uint32 frameCount = 0;
    pd_t *pd = (pd_t*) proctab[pid].prPDBR;
    uint32 i;
//    for (i = 8; i < ENTRIES; i++)
//    {
//        if (pd[i].pd_pres == 1)
//        {
//            uint32 j;
//            pt_t *pt = (pt_t*) (pd[i].pd_base << 12);
//            for (j = 0; j < ENTRIES; j++)
//            {
//                if (pt[j].pt_pres == 1)
//                {
//                    ++frameCount;
//                }
//            }
//        }
//    }
    frameCount = proctab[pid].noFfsPages;
    return frameCount;
}

uint32 allocated_virtual_pages ( pid32 pid )
{
    uint32 virtualPageCount = 0;
    pd_t *pd = (pd_t*) proctab[pid].prPDBR;
#ifdef DEBUG
    sync_printf("process :: %d pdbr :: %x\n", currpid, proctab[pid].prPDBR);
#endif
//    int i, j;
//    for (i = 0; i < ENTRIES; i++)
//    {
//        if (pd[i].pd_pres == 1)
//        {
//            pt_t *pt = (pt_t*) (pd[i].pd_base << 12);
//            for (j = 0; j < ENTRIES; j++)
//            {
//                if (pt[j].pt_valid == 1)
//                {
//                    virtualPageCount++;
//                }
//            }
//        }
//    }
    virtualPageCount = proctab[pid].noVirtualPages;
    return virtualPageCount;
}
//uint32 free_ffs_pages ( )
//{
//    struct memblk *memptr;
//    uint32 free_ffs;
//    free_ffs = 0;
//    for (memptr = ffslist.mnext; memptr != NULL; memptr = memptr->mnext)
//    {
//        free_ffs += memptr->mlength;
//    }
//    kprintf("%10d bytes of free memory\n", free_ffs);
//    for (memptr = ffslist.mnext; memptr != NULL; memptr = memptr->mnext)
//    {
//        kprintf("[0x%08X to 0x%08X]\n", (uint32) memptr,
//                ((uint32) memptr) + memptr->mlength - 1);
//    }
//    kprintf("Getting block of free memory\n");
//    //unsigned long address = (unsigned long) getblk(&ffslist, PAGE_SIZE);
//    free_ffs = 0;
//    kprintf("New ffs space\n");
//    for (memptr = ffslist.mnext; memptr != NULL; memptr = memptr->mnext)
//    {
//        free_ffs += memptr->mlength;
//    }
//    kprintf("%10d bytes of free memory\n", free_ffs);
//    for (memptr = ffslist.mnext; memptr != NULL; memptr = memptr->mnext)
//    {
//        kprintf("[0x%08X to 0x%08X]\n", (uint32) memptr,
//                ((uint32) memptr) + memptr->mlength - 1);
//    }
//
//    return 0;
//}
