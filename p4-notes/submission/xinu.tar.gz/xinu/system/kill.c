/* kill.c - kill */

#include <xinu.h>
/*------------------------------------------------------------------------
 *  kill  -  Kill a process and remove it from the system
 *------------------------------------------------------------------------
 *
 *  */
//#define DBG
syscall kill ( pid32 pid /* ID of process to kill	*/
)
{
    intmask mask; /* Saved interrupt mask		*/
    struct procent *prptr; /* Ptr to process's table entry	*/
    int32 i; /* Index into descriptors	*/

    mask = disable();
    if (isbadpid(pid) || (pid == NULLPROC)
    || ((prptr = &proctab[pid])->prstate) == PR_FREE)
    {
        restore(mask);
        return SYSERR;
    }

    if (--prcount <= 1)
    { /* Last user process completes	*/
        xdone();
    }

    send(prptr->prparent, pid);
    for (i = 0; i < 3; i++)
    {
        close(prptr->prdesc[i]);
    }
#ifdef DEBUG
    sync_printf("kill :: clearing page\n");
#endif
    pd_t *pd = (pd_t*) proctab[currpid].prPDBR;
    if ((uint32) pd != (XINU_PAGES*PAGE_SIZE))
    {
        uint32 old_pdbr = read_cr3();
        write_cr3(XINU_PAGES * PAGE_SIZE);
        for (i = 0; i < ENTRIES; i++)
        {

            if (pd[i].pd_pres == 1 && i >= 8)
            {
                uint32 j;
                pt_t *pt = (pt_t*) (pd[i].pd_base << 12);
                for (j = 0; j < PAGE_SIZE / 4; j++)
                {

                    if (pt[j].pt_pres == 1)
                    {
                        // implement
                        freeblk(&ffslist, (char*)(pt[j].pt_base << 12), PAGE_SIZE);
                    }
                    pt[j].pt_pres = 0;
                    pt[j].pt_valid = 0;
                    pt[j].pt_alloc = 0;
                    pt[j].pt_base = 0;
                }
            }
            else if (i >= (XINU_PAGES / (PAGE_SIZE / 4)))
            {

                pd[i].pd_pres = 0;
                pd[i].pd_valid = 0;
                pd[i].pd_alloc = 0;
                pd[i].pd_base = 0;
            }
            else
            {
                pd[i].pd_pres = 0;
                pd[i].pd_valid = 0;
                pd[i].pd_alloc = 0;
                pd[i].pd_base = 0;

            }
        }
    }

    freestk(prptr->prstkbase, prptr->prstklen);

    switch (prptr->prstate)
    {
        case PR_CURR:
            prptr->prstate = PR_FREE; /* Suicide */
            resched();

        case PR_SLEEP:
        case PR_RECTIM:
            unsleep(pid);
            prptr->prstate = PR_FREE;
            break;

        case PR_WAIT:
            semtab[prptr->prsem].scount++;
            /* Fall through */

        case PR_READY:
            getitem(pid); /* Remove from queue */
            /* Fall through */

        default:
            prptr->prstate = PR_FREE;
    }

    restore(mask);
    return OK;
}
