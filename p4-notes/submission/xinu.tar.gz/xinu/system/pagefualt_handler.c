/*
 * pagefualt_handler.c
 *
 *  Created on: 13-Nov-2020
 *      Author: prati
 */
#include <xinu.h>
//#define DBG
//#define DBG_ADDR
void pagefault_handler ( )
{

  // write_cr3((uint32) proctab[NULLPROC].prPDBR);
  //    intmask mask; /* Saved interrupt mask     */
  //    mask = disable();
  uint32 old_pdbr = read_cr3();
  write_cr3(XINU_PAGES * PAGE_SIZE);
#ifdef DBG
    sync_printf("pagefault_handler:: pdbr->0x%0X\n", old_pdbr);
#endif
    uint32 addr = read_cr2();
#ifdef DBG_ADDR
    sync_printf("pagefault_handler:: value returned from cr2: %x\n", addr);
#endif
    uint32 pdIndex = (uint32) addr >> 22;
    uint32 ptIndex = ((uint32) addr & 0x003FF000) >> 12;
    pd_t *pd = (pd_t*) (proctab[currpid].prPDBR);
#ifdef DBG_ADDR
    sync_printf("pagefault_handler:: addr %x\n", addr);
    sync_printf("pagefault_handler:: pdIndex %d\n", pdIndex);
    sync_printf("pagefault_handler:: ptIndex %d\n", ptIndex);
#endif
    pt_t *pt = (pt_t*) (pd[pdIndex].pd_base << 12);

    if (pt[ptIndex].pt_valid == 1) {
      uint32 phys_addr = getblk(&ffslist, PAGE_SIZE);
#ifdef DBG
      sync_printf("Physical memory :: addr %x\n", phys_addr);
#endif
        pt[ptIndex].pt_base = phys_addr >> 12;
        pt[ptIndex].pt_pres = 1;
        proctab[currpid].noFfsPages++;
        pt[ptIndex].pt_alloc = 1;
        // pt[ptIndex].pt_valid = 1;
    } else {
      sync_printf("P%d:: SEGMENTATION_FAULT\n", currpid);
      kill(currpid);
    }

    write_cr3(old_pdbr);
//restore(mask);
}
