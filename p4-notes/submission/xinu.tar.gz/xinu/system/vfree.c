/*
 * vfree.c
 *
 *  Created on: 15-Nov-2020
 *      Author: prati
 */

#include<xinu.h>

syscall vfree ( char * addr, uint32 size )
{
    intmask mask; /* Saved interrupt mask     */
    mask = disable();
    uint32 old_pdbr=read_cr3();
    write_cr3(XINU_PAGES*PAGE_SIZE);
    uint32 i;
#ifdef DEBUG
    sync_printf("vfree:: called\n");
#endif
    size = size / PAGE_SIZE;
    uint32 occupied = 0;
    uint32 startIndex = ((uint32) addr - 0x2000000) >> 12;
#ifdef DEBUG
    sync_printf("vfree:: startIndex %d\n", startIndex);
#endif
    uint32 z;
    for (z = startIndex; z < 8 * 16 * 1024; z++)
    {
        if (proctab[currpid].arr[z] == 1)
            occupied++;
        else
            break;
    }
#ifdef DEBUG
    sync_printf("vfree:: occupied %d\n", occupied);
    sync_printf("vfree:: size %d\n", size);
#endif
    if (!(occupied > size))
    {
        write_cr3(old_pdbr);
        sync_printf("vfree:: failed\n");
        return SYSERR;
    }

    for (z = startIndex; z < startIndex + size; z++)
        proctab[currpid].arr[z] = 0;
    uint32 pdIndex = (uint32) addr >> 22;
    uint32 ptIndex = ((uint32) addr & 0x003FF000) >> 12;
#ifdef DEBUG
    sync_printf("vfree:: pdIndex %d\n", pdIndex);
    sync_printf("vfree:: ptIndex %d\n", ptIndex);
#endif
    uint32 noOfFramesToDel = size;
    pd_t *pd = (pd_t*) proctab[currpid].prPDBR;

    while (noOfFramesToDel)
    {
#ifdef DEBUG
        sync_printf("vfree:: pdIndex :: %x\n", pdIndex);
        sync_printf("vfree:: ptIndex :: %x\n", ptIndex);
        sync_printf("vfree:: proctab[currpid].prPDBR :: %x\n",
                proctab[currpid].prPDBR);
        sync_printf("vfree:: noOfFramesToDel :: %d\n", noOfFramesToDel);
#endif
        pt_t *pt = (pt_t*) (pd[pdIndex].pd_base << 12);
#ifdef DEBUG
        sync_printf("vfree:: pd[pdIndex].pd_base :: %x\n", pd[pdIndex].pd_base);
#endif
        if (pt[ptIndex].pt_pres == 1)
        {
//implement
        }
        pt[ptIndex].pt_valid = 0;
        pt[ptIndex].pt_pres = 0;
        pt[ptIndex].pt_write = 0;
        noOfFramesToDel--;
        proctab[currpid].noVirtualPages--;
        ptIndex++;
        if (ptIndex == (PAGE_SIZE / 4))
        {
            pdIndex++;
            ptIndex = 0;
        }
    }
    write_cr3(old_pdbr);
    restore(mask);
    return OK;
}
