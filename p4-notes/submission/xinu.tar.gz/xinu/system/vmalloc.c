/*
 * vmalloc.c
 *
 *  Created on: 15-Nov-2020
 *      Author: prati
 */
#include <xinu.h>
//#define DEBUG_RETURN
uint32 contiguousAllocation ( uint32 reqNoOfFrames )
{

    uint32 availableFrame = 0;
    uint32 retStartAddr = 0;
    uint32 isBreakPresent = 0;

    pd_t *pd = (pd_t*) proctab[currpid].prPDBR;
    uint32 i;
    uint32 iStartValue;
    uint32 jStartValue;
    for (i = 8; i < ENTRIES;)
    {
//#ifdef DEBUG
//    sync_printf("contiguousAllocation:: i == %d\n", i);
//#endif
        if (pd[i].pd_valid == 1)
        {
            if (availableFrame == 0)
                iStartValue = i;
            pt_t *pt = (pt_t*) (pd[i].pd_base << 12);
            uint32 j;
//#ifdef DEBUG
//    sync_printf("contiguousAllocation:: scanning table\n");
//#endif
            for (j = 0; j < ENTRIES; j++)
            {

//#ifdef DEBUG
//    sync_printf("contiguousAllocation:: j == %d\n", j);
//#endif
                if (availableFrame == reqNoOfFrames)
                {
                    uint32 retVal;
#ifdef DEBUG
                    sync_printf("iStartValue :: %x\n", iStartValue);
#endif
                    retVal = (iStartValue << 22) | ((jStartValue) << 12);
                    bool8 isFound = 0;
                    uint32 startIndex = (retVal - 0x2000000) >> 12;
#ifdef DEBUG
                    sync_printf("startIndex :: %x\n", startIndex);
#endif
                    uint32 z;
                    for (z = startIndex; z < availableFrame + startIndex; z++)
                    {
                        proctab[currpid].arr[z] = 1;
                    }
#ifdef DEBUG
                    sync_printf("z :: %x\n", z);
                    sync_printf("retVal :: %x\n", retVal);
#endif
                    return retVal;
                }
                if (isBreakPresent == 1)
                {
//#ifdef DEBUG
//                    sync_printf("break present\n");
//#endif
                    retStartAddr = 0;
                    availableFrame = 0;
                    isBreakPresent = 0;
                }
                if (pt[j].pt_valid == 0)
                {
                    if (availableFrame == 0)
                        jStartValue = j;
                    availableFrame++;
//#ifdef DEBUG
//                    sync_printf("availableFrame :: %d\n", availableFrame);
//#endif
                }
                else
                {
                    isBreakPresent = 1;
//#ifdef DEBUG
//                    sync_printf("isBreakPresent :: %d\n", isBreakPresent);
//#endif
                }

            }
            i++;
        }
        else
        {
            uint32 pageDirEntry = allocateTable();
#ifdef DEBUG
            sync_printf("pd[i].pd_pres == 0\n");
            sync_printf("contiguousAllocation:: pageDirEntry :: %x\n",
                    pageDirEntry);
#endif
            if (pageDirEntry != SYSERR)
            {
                pd[i].pd_base = pageDirEntry >> 12;

#ifdef DEBUG
                sync_printf("contiguousAllocation:: pd[%d].pd_base :: %x\n", i,
                        pd[i].pd_base);
#endif
                pd[i].pd_alloc = 1;
                pd[i].pd_pres = 1;
                pd[i].pd_valid = 1;
            }
        }
    }

    return SYSERR;
}

char* vmalloc ( uint32 size )
{
    intmask mask; /* Saved interrupt mask     */
    mask = disable();
    uint32 old_pdbr = read_cr3();
    write_cr3(XINU_PAGES * PAGE_SIZE);
#ifdef DEBUG
    sync_printf("vmalloc:: contiguousAllocation\n");
#endif
    uint32 noOfFrames = size / PAGE_SIZE;
    uint32 startAddr = contiguousAllocation(noOfFrames);
    if (startAddr == SYSERR)
    {
        restore(mask);
        return (char*) SYSERR;
    }
#ifdef DEBUG
    sync_printf("vmalloc:: addr from allocation :: %x\n", startAddr);
#endif
    uint32 pdIndex = (startAddr & (0xFFC00000)) >> 22;
    uint32 ptIndex = (startAddr & (0x003FF000)) >> 12;
    pd_t *pd = (pd_t*) proctab[currpid].prPDBR;
#ifdef DEBUG
    sync_printf("vmalloc:: pdIndex :: %x\n", pdIndex);
    sync_printf("vmalloc:: ptIndex :: %x\n", ptIndex);
    sync_printf("vmalloc:: proctab[currpid].prPDBR :: %x\n",
            proctab[currpid].prPDBR);
    sync_printf("vmalloc:: noOfFrames :: %d\n", noOfFrames);
#endif

    if (pd[pdIndex].pd_alloc)
    {
        if (pd[pdIndex].pd_pres)
        {
            while (noOfFrames)
            {
                pt_t *pt = (pt_t*) (pd[pdIndex].pd_base << 12);
#ifdef DEBUG
                sync_printf("vmalloc:: pd[pdIndex].pd_base :: %x\n",
                        pd[pdIndex].pd_base);
#endif
                pt[ptIndex].pt_valid = 1;
                pt[ptIndex].pt_pres = 0;
                // pt[ptIndex].pt_write = 1;
//#ifdef DEBUG
//                sync_printf("vmalloc:: ptIndex :: %d\n", ptIndex);
//#endif
                proctab[currpid].noVirtualPages++;
                ptIndex++;
                noOfFrames--;
                if (ptIndex == (ENTRIES))
                {
                    pdIndex++;
                    ptIndex = 0;
                }
            }
        }
    }

    char* retVal = (char*) startAddr;
#ifdef DEBUG_RETURN
    sync_printf("vmalloc:: startAddr :: %x\n", startAddr);
    sync_printf("vmalloc:: retVal :: %x\n", retVal);
#endif
    write_cr3(old_pdbr);
    restore(mask);
    return retVal;
}

