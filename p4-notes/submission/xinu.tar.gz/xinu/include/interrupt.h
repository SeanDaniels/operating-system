/* interrupt.h */

extern	uint16	girmask;	/* mask of interrupts being serviced	*/
				/* a bit of 1 corresponds to an		*/
				/* interrupt that is allowed.		*/
