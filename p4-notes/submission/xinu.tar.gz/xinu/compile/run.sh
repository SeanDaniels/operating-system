vboxmanage controlvm backend poweroff
make clean
vboxmanage startvm backend --type headless
make
